function agregarLike( elemento ){
    let spanNumLikes = elemento.querySelector( ".numLikes" );
    numlikes = Number( spanNumLikes.textContent );
    numLikes += 1;
    spanNumLikes.textContent = numLikes;
    console.log( numLikes);
}
////////////////////////////////////////////////////////
function removeElement (elemento){
    elemento.remove();
}
////////////////////////////////////////////////////////
function showAlert() {
    var Text = "Ninja was liked";
    alert (Text);
}
////////////////////////////////////////////////////////
function logIn() {
    var uno = document.getElementById('logIn');
    if (uno.innerText == 'Logout') 
            uno.innerText = 'Login';
    else uno.innerText = 'Logout'; 
}